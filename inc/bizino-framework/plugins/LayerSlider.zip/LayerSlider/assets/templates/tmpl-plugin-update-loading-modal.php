<?php defined( 'LS_ROOT_FILE' ) || exit; ?>
<script type="text/html" id="tmpl-plugin-update-loading-modal">
	<div id="ls-loading-modal-window">
		<div id="lse-loading">
			<lse-loading-indicator></lse-loading-indicator>
		</div>
		<div class="ls-loader-message">
			<?= __('Updating LayerSlider...', 'LayerSlider') ?>
		</div>
	</div>
</script>